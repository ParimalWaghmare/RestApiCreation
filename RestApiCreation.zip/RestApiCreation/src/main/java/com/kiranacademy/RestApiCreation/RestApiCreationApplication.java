package com.kiranacademy.RestApiCreation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiCreationApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiCreationApplication.class, args);
	}

}
