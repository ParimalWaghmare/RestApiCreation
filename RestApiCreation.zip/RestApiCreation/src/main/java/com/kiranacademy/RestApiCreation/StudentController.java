package com.kiranacademy.RestApiCreation;

/* 
To run this API, follow below steps:-
* 
* 1) localhost:8080/students - get
* 2) localhost:8080/student/1  - get
* 3) localhost:8080/student  - post ( add student object in arraylist )
* 4) localhost:8080/student/1  - delete 
* 5) localhost:8080/student - put (update)
* 
* 
*  JSON String format is :-
*  
*  {"rno":1,"marks":90}
*  
*  */



import java.util.ArrayList;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("http://localhost:8080")
public class StudentController {
	
	ArrayList <Student> arraylist = new ArrayList <Student>();
	
	
	StudentController(){

		
		Student student1 = new Student(1, 80);
		Student student2 = new Student(2, 90);
	
		
		
		arraylist.add(student1);
		arraylist.add(student2);
		
		
	}
	
	@GetMapping("student")
	ArrayList allstudents()
	{
		return arraylist;
	}
	
	// @PathVariable assign value of path variable to local variable
	// localhost:8080/student/1
	
	@GetMapping("student/{rno}")
	public Student getstudent(@PathVariable int rno)
	{
		
		for (Student student : arraylist) {
			
			if(student.rno==rno)
			{
				return student;
			}
			
		}
		
		return null;
		
	}
	
	
	
	// {"rno":3,"marks":50}
	@PostMapping("student")
	public ArrayList addStudent(@RequestBody Student student)
	{
		
		arraylist.add(student);
		return arraylist;
	}
	
	
	@DeleteMapping("student/{rno}")
	public String deleteStudent(@PathVariable int rno)
	{
		
		Student deletestudent=null;
		
		for (Student student : arraylist) {
			
			if(student.rno==rno)
			{
				deletestudent= student;
				break;
			}
		}
		arraylist.remove(deletestudent);
		
		
		return "Record Deleted";
	}
	
	
	
	// {"rno"2,"marks":35} , using this JSON String , @RequestBody will create Student object clientStudent.
	
		// for updation , use @PutMapping
	@PutMapping("student")
	public ArrayList updatestudent(@RequestBody Student clientstudent)
	{
		Student updatestudent= null;
		
		for (Student student : arraylist) {
			
			if(student.rno==clientstudent.rno)
			{
				updatestudent=student;
			}
			
	
			
			
		}	
		
		updatestudent.setMarks(clientstudent.getMarks());
		return arraylist;
		
		
		
	}
	
	

}
